#şehir #neraxis #başkent

[[Neraxis]]'in başkenti.

## Genel Bilgi
- [[Neraxis]]'in başkenti
- Kıtanın en büyük [[Akademi]]si burada
- Güçlü ve büyük bir şehir
