#krallık #vasal #Rhinet #neraxis

[[Neraxis]]'in vasal devleti. İsim gergedanı ifade eden "rhino"dan geliyor — bulundukları coğrafya olan Boynuz (Gergedan) Yarımadası'ndan esinlenilmiş.

-- -
## Genel Bilgi

- **Başkent:** *Rhinet City*
- **Yönetim Biçimi:** *Mutlak Monarşi*
- **Yönetim Anlayışı:** *Doğal seçilime inanır*
- **Sembol:** *Gergedan*
- **Askeri Güç:** *Ağır zırhlı piyadeler*
- **Ana Gelir:** *Çelik Ticareti*
- **Yasaklar:** *Yok Denecek Kadar Az*
- **Coğrafya:** *Sert Toprak + Engebeli Arazi*
- **Takvim:** *Yıkım Takvimi (Kesin Değil)*

- --
## Genel Bilgi
- [[Neraxis]]'in bulunduğu kıtanın en büyük yarımadasının kuzeyindeki küçük bir yarımada
- Büyük şehirleri yok, küçük köyler topluluğu
- Maden açısından çok zengin
- İklimi sert, kurak; kışın soğuk — halk doğal olarak dayanıklı

## Ekonomi
- **Rhinet Çeliği** (Kara Çelik) — kıtanın en sağlam çeliği
- [[Neraxis]]'e zırh, metal parçalar ve imalat ürünleri göndererek geçimini sağlıyor
- [[Neraxis]]'e gönderilen zırhlar ince ve hafif, kendi askerleri için ağır ve kalın

## Ordu
- Ağır zırhlı, yavaş ama durdurulamaz savaş birimleri
- Gergedan boynuzlu ve motifli zırhlar
- Ağır topuz ve balta tercih ediyorlar
- Arenalarda gergedanlarla dövüşüyorlar

## Siyasi Durum
- [[Neraxis]] kralının ölmesinden önce zaten bağımsızlık düşünüyordu
- [[Küçük Prens]]'nin kral olmasından sonra ayaklanma eğilimi arttı
