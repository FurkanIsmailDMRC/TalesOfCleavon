#krallık #SouthernKingdoms 

-- -
## Genel Bilgi

- Bu krallıklar, şuanda ana hikayemizin geçtiği krallıkların **[[Araplar]]**'ın çölleri yüzünden güneye geçememesinden dolayı güney krallıkları ile kesin olarak tanışmamışlardır.
- **[[Alderyn]]** Güney krallıklarının bazıları ile ticaret yapmaya devam etse bile kim olduklarını kesin olarak bilmemektedirler. Gezginler (Örneğin: **[[Çelebi]]**) kitaplarında flux dünyasının bilinenden çok daha büyük olduğunu söylemektedir.

-- -
