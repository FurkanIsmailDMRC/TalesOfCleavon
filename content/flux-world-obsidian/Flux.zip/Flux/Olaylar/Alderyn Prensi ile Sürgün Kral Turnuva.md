#alderyn #sürgün #prens #olay

## Olay : Turnuva

**tür:** *sahne*
**karakterler:** *"[[Sürgün Kral]], [[Alderyn Prensi]]"* 
**konum:** *"[[Alderyn]] turnuva arenası"*
## Kimler Var

- **[[Sürgün Kral]]** — kapüşonlu, kimliği gizli
- **[[Alderyn Prensi]]** — turnuvanın her zamanki şampiyonu
- **[[Alderyn Prensi]]** 'nin sevgilisi — tribünde izliyor
- Turnuva yetkilileri
- Seyirciler

## Ne Oldu

**[[Alderyn]]** turnuvalarına katılmak için isim kaydı yapılıyor. Kapüşonlu, yüzü görünmeyen biri geliyor. Herkes şaşkınlıkla bakıyor. **[[Alderyn Prensi]]** yetkililere soruyor: kim bu?

Yetkili: _"Kendisine Sürgün Kral diyor efendim."_

Alderyn Prensi omuz silkiyor, kafası rahat. Sevgilisi tribünde. Arena'ya giriyorlar. Dövüş başlıyor.

**[[Sürgün Kral]]** hayatında hiç düello kaybetmemiş. Çevik ve hızlı hamlelerle Alderyn Prensinin saldırılarından kaçınıyor. Alderyn prensi tamamen zırhlı bir şekilde savaşıyorken sürgün kral yalnızca siyah bir tulum ile savaşıyor. Sürgün Kral aniden yaklaşarak [[Alderyn Prensi]]'nin diz kapağının arkasını kesiyor. Prens dengesini kaybedip yere çöküyor ve böylece Sürgün Kral turnuva galibi oluyor.

**[[Alderyn Prensi]]** şoka uğruyor, kontrolünü kaybediyor, saldırıya geçiyor — öldürmeye çalışıyor. Yetkililer araya giriyor. Bu sırada Alderyn Prensi bir yetkiliyi öldürüyor. Prens olduğu için üstü kapatılıyor.

**[[Sürgün Kral]]** kapüşonunu açıyor.

Tribünlerde kısa süreli bir sessizlik oluşuyor. Bazı seyirciler yüzünü gördükleri anda arenadan koşarak çıkmaya başlıyor. Bir kesim **[[Alderyn]]** kralına haber vermek için koşuyor, **[[Neraxis]]** ile arası kötü olduğundan bu büyük bir fırsat. Diğer kesim atlarına atlayıp Neraxis 'e doğru yola koyuluyor, Neraxis 'teki kraliçeye söylemek için.

## Neden Önemli

**[[Sürgün Kral]]** kimliğini saklayarak turnuvaya girdi. Kazanarak kendini tüm dünyaya gösterdi, "Sürgün Kral" adını bizzat ilan etti. Bu andan itibaren artık herkes onu biliyor.

## Sonucu

- **[[Alderyn]]** - **[[Neraxis]]** gerilimi tırmandı
- **[[Sürgün Kral]]** 'in varlığı artık gizli değil
- **[[Alderyn Prensi]]** 'nin kibri ilk kez kırıldı