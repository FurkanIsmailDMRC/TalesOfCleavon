#kavram #dünyainşası #flux

Bu dünyada "büyü" yok. Onun yerine [[Flux Elementi]]'na maruz kalmaktan kaynaklanan genetik mutasyonlar var.

## Nasıl Çalışır
- [[Flux Elementi]]'na fazla maruz kalmak mutasyona yol açıyor
- Sonuç tamamen şansa bağlı — iyi de olabilir, kötü de
- Dünyada gen teknolojisi gelişmediği için kontrol edilemiyor

## İyi Mutasyon Örnekleri
- Uçabilmek
- Çok hızlı koşabilmek
- Alev püskürtebilmek
- Uzun süre su altında kalabilmek

## Kötü Mutasyon Örnekleri
- Körlük
- Felç
- Yürüyememek

## Toplumsal Tutum
- [[Neraxis]] — mutantları kabul eder, [[Akademi]]'de eğitir, savaşta kullanır
- [[Alderyn]] — mutantları öldürür, mutasyon yasaktır, [[Mutant Katili]] serbest bırakılmıştır
- [[Krater Adası]] — mutasyonlar o kadar normalleşti ki halk farkında bile değil

## Arınma
[[Akçaağaç Ormanı]] özü vücuttaki mutajeni temizliyor. [[Alderyn]]'de halk bu yüzden düzenli olarak akçaağaç özlü küvetlere giriyor.
