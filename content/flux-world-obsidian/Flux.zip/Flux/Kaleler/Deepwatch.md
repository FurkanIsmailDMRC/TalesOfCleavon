#kale #craterisland #başkent

[[Krater Adası]]'ın başkenti.

-- -
## Genel Bilgi

- [[Krater Adası]]'ın başkenti
- Krater Geçidi'ne uzak konumda — bu yüzden tersane [[Crownkeel]]'e taşındı.

-- -

