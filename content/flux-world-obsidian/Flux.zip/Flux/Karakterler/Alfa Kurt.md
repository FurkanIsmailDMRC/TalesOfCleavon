#karakter #tengri #lider

[[Tengri]] halkının saygı duyduğu yaşlı lider. [[Tengri Ana Karakteri]]'nin babası.

## Fiziksel Özellikler
- Çok yaşlı
- Yarı kel
- Beyaz saçları arkadan bağlı

## Kişilik
- Oturmayı kalkmayı bilen biri — ölçülü, deneyimli
- Sözleri ağır basar

## Anlatısı
Çok uzaklardaki [[Tengri]] hakkında şöyle söyler:
> "Kuzeydoğuda at üstünde giden, okçulukta ustalaşan bir kavim var. Durdurulamazlar. Bize barbar derler ama asıl barbarlar onlar."

## İlişkiler
- Oğlu: [[Tengri Ana Karakteri]]
