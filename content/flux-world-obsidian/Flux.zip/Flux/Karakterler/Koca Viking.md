#vikingler #karakter 

-- - 
## Genel Özellikler

- **Boy:** *2.00-2.50m*
- **Kilo:** *100-150kg*
- **Sosyal konum:** *Asker*
- **Kişisel Özellikler:** *Sıcakkanlı, Komik, Canayakın*
- **Irk:** *[[Vikingler]]*

-- -

