#karakter #Deamor #kral 

---
## Genel Bilgi

- **Boy:** *1.80-1.85*
- **Kilo:** *75 kg*
- **Sosyal Statü:** *Kral*
- **Irk:** *[[Deamor]]*
- -**Kişisel Özellikler:** *Samimi, Sabırlı, Güleryüzlü, Pozitif, Bilgin*
- **Yaş:** *48*

---

- **[[Deamor]] krallığının kralıdır.
- Samimi olmasıyla ve halkla olan etkileşimleri ile tanınır.