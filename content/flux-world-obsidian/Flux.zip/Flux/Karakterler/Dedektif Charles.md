#karakter #neutral 

![[charles.jpg|204]]

Hikayedeki dedektif karakterdir.
Mutant katilinin cinayetlerini sorgular.
cesetlerdeki işaretleri çözmeye çalışır.

---

## Genel Bilgi

- 