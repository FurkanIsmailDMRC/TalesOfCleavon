#karakter #bulucu #neutral 

