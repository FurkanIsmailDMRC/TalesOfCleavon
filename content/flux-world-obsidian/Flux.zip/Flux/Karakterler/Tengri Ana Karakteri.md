#karakter #tengri #anakarakter

[[Tengri]] halkından ana karakterlerden biri. Hırslı ve güçlü.

## Genel Bilgi
- [[Tengri]] halkından
- Hırslı ve güçlü
- Zamanı geldiğinde tüm krallıklarla baş başa kalacak

## İlişkiler
- Babası: [[Alfa Kurt]]
- Aşk üçgeni: bir kız var, iki erkek arasında kalıyor — biri bu karakter, diğeri [[Alderyn]] veya [[Neraxis]]'ten bir soylu

## Büyük Savaş
[[Tengri]] diğer krallıklara tek başına savaş açacak. [[Alderyn]], [[Neraxis]] ve batı şehirleri birlikte hareket etmek zorunda kalacak.
