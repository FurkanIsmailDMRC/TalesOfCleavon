#alderyn #karakter 

-- -
## Genel Özellikler

**Boy:** *1.70-1.75m*
**Kilo:** *55-60kg*
**Sosyal Statü:** *Soylu*
**Irk:** *[[Alderyn]]*
**Kişisel Özellikler:** *Yardımsever, Titiz, Düzenli*
**Yaş:** *23*

-- -
## İlişki

- Kendisi Kıtanın en güzel kadını olarak da bilinir.
- **[[Alderyn Prensi]]** ile sevgilidir.

-- - 
## Aile

- Babası ticaret ile uğraşan zengin bir adamdır.
- Annesi liderlik becerisi ile öne çıkar ve çarşıda sık sık kadınlar arası sohbetler düzenler.