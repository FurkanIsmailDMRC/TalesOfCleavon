#neraxis #eyalet 

---
## Genel Bilgi

- **[[Neraxis]]**'in **[[Lumiere Antlaşması]]**'nda belirlediği eyaletin kuzey kesimidir.
- Arazisi engebelidir.
- Nüfus azdır.